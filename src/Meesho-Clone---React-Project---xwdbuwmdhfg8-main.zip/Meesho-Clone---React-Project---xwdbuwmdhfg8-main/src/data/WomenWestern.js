const WomenWestern = [
    {
        heading : "Topwear",
        data : ["Tops","Dresses","Sweaters","Jumpsuits"]
    },
    {
        heading : "Bottomwear",
        data : ["Jeans","Jeggings","Palazzos","Shorts","Skirts"]
    },
    {
        heading : "Innerwear",
        data : ["Bra","Briefs"]
    },
    {
        heading : "Sleepwear",
        data : ["Nightsuits","Babydolls"]
    },
]


export default WomenWestern