const Electronics = [
    {
        heading : "Mobile & Accessories",
        data : ["All Mobile & Accessories","Smartwatches","Mobile Holders","Mobile cases and covers"]
    },
    {
        heading : "Appliances",
        data : ["All Appliances","Grooming","Home Appliances"]
    },
]

export default Electronics