import { createContext } from "react";

const CreateItem = createContext();

export default CreateItem;